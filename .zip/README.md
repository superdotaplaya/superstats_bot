# Bot Base

> A simple Discord.js bot base.

This is an extremely simple Discord.js bot base with a config loader / validator, a command handler, and a simple ping command. All code should be pretty self-explanatory.

## Hack the Source, Luke!

Just fork the repo, clone your newly made fork, and copy the `config-example.json` file that is provided. It should be pretty simple to make your own commands, expand the command handler, etc.

It would be appreciated if you would provide a link back to this original version though, as well as an optional link to [Rayzr's Discord server](https://discord.io/rayzrdevofficial).

## Join Me

[![Discord Badge](https://github.com/Rayzr522/ProjectResources/raw/master/RayzrDev/badge-small.png)](https://discord.io/rayzrdevofficial)
